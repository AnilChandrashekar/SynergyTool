package com.synergy.synergytool.repository;


import org.springframework.data.mongodb.repository.MongoRepository;
import com.synergy.synergytool.model.AccountInfo;

/*
* This class is implementing the MongoRepository interface for User.
* Annotate this class with @Repository annotation
* */

public interface SynergyRepository extends MongoRepository<AccountInfo, Integer> {

}
